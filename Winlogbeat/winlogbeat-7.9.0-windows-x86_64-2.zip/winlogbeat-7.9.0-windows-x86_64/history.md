v1.1

新增如下設定:

winlogbeat.registry_file: evtx-registry.yml 

winlogbeat.event_logs:
  - name: System
    ignore_older: 168h

processors:
  - add_locale: ~
  